<template>
    <div class="about-page">
        <h1>About us</h1>
        <p>We're a VFS based team.</p>
    </div>

</template>

<script>
    export default {
        name: 'AboutPage'
    }
</script>

<style scoped>
    .about-page {
        margin-top: 20px;
        text-align: center;
    }
</style>