<script>
  export default {
    name: 'App'
  }
</script>

<template>
    <div>
        <nav style="margin-bottom: 20px">
            <router-link to="/">Landing</router-link>
            <router-link to="/about">About</router-link>
            <router-link to="/leaderboard">Leaderboard</router-link>
            <router-link to="/gallery">Gallery</router-link>
            <router-link to="/contact">Contact Us</router-link>
        </nav>

        <main>
            <router-view />
        </main>
    </div>
</template>

<style>
    nav {
        text-align: center;
    }

</style>